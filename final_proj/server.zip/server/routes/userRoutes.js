const express = require("express");
const mongoose = require("mongoose");
const router = express();

const ItemModel = require("../models/item");
const userModel = require("../models/user");


router.get("/getImg", async (req, res) => {
    console.log("test");


    try {

        const item = await ItemModel.find({ name: "jyothiraditya" });



        res.status(200).send(item);
        //res.type("Content-Type", item[0].img.ContentType);
    } catch (error) {
        res.status(500).send(error);
    }



});


router.post("/upload", async (req, res) => {
    console.log(req.body);
    const { name, email,title,comment } = req.body;

    let item = new ItemModel({
        name,
        email,
        title,
        comment
    });

    const reply = { message: "" };
    const { data, mimetype } = req.files.file;

    item.img.Data = data;
    item.img.ContentType = mimetype;

    try {
        await item.save();
        reply["success"] = 1;
        reply["message"] = "Upload Successful";

        res.status(200).send(reply);
    } catch (error) {
        reply["success"] = 0;
        reply["message"] = "Error";
        res.status(500).send(reply);
    }
}


);
module.exports = router;