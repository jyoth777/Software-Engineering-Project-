const mongoose = require("mongoose");
const itemSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    comment: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    img: {
        Data: Buffer,
        ContentType: String
    }

});
const Item = mongoose.model('Item', itemSchema);
module.exports = Item;